import { ANTHROPIC_API_KEY } from './theme';

export async function analyzeFoodImage(base64Image, mimeType = 'image/jpeg') {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: mimeType,
                data: base64Image,
              },
            },
            {
              type: 'text',
              text: `Analyze this food image and return ONLY a JSON object with these exact fields:
{"name":"specific food name","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number,"serving":"serving size","notes":"1-2 sentence health insight","confidence":"high|medium|low"}
Be specific. Estimate for a typical restaurant or home serving. No markdown, no extra text, JSON only.`,
            },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const text = data.content.map(b => b.text || '').join('');
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}
