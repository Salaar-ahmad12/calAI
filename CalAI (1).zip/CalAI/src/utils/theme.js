export const Colors = {
  bg: '#0A0A0F',
  bg2: '#13131A',
  bg3: '#1C1C26',
  bg4: '#252530',
  accent: '#A8FF3E',
  accent2: '#7BDA2B',
  text: '#F0F0F5',
  text2: '#9090A0',
  text3: '#5A5A6A',
  protein: '#4A9EFF',
  carbs: '#FF8C42',
  fat: '#FF6B9D',
  red: '#FF4A6A',
  orange: '#FF8C42',
  border: 'rgba(255,255,255,0.06)',
  borderLight: 'rgba(255,255,255,0.1)',
};

export const ANTHROPIC_API_KEY = 'YOUR_API_KEY_HERE'; // Replace with your key
