import React, { createContext, useContext, useState, useCallback } from 'react';

const AppContext = createContext(null);

const INITIAL_ENTRIES = [
  { id: '1', name: 'Scrambled Eggs & Toast', meal: 'Breakfast', cal: 420, protein: 22, carbs: 38, fat: 18, emoji: '🍳', date: new Date().toDateString() },
  { id: '2', name: 'Grilled Chicken Bowl', meal: 'Lunch', cal: 580, protein: 48, carbs: 52, fat: 14, emoji: '🥗', date: new Date().toDateString() },
  { id: '3', name: 'Almonds (1 oz)', meal: 'Snack', cal: 165, protein: 6, carbs: 6, fat: 14, emoji: '🫘', date: new Date().toDateString() },
  { id: '4', name: 'Protein Shake', meal: 'Snack', cal: 180, protein: 22, carbs: 12, fat: 3, emoji: '🥤', date: new Date().toDateString() },
];

const WEEK_DATA = [
  { day: 'Mon', cal: 1890, goal: 2000 },
  { day: 'Tue', cal: 2210, goal: 2000 },
  { day: 'Wed', cal: 1650, goal: 2000 },
  { day: 'Thu', cal: 1980, goal: 2000 },
  { day: 'Fri', cal: 1720, goal: 2000 },
  { day: 'Sat', cal: 2050, goal: 2000 },
  { day: 'Sun', cal: null, goal: 2000 },
];

export const GOALS = {
  calories: 2000,
  protein: 160,
  carbs: 250,
  fat: 65,
};

export const AppProvider = ({ children }) => {
  const [entries, setEntries] = useState(INITIAL_ENTRIES);
  const [streak, setStreak] = useState(7);
  const [weekData, setWeekData] = useState(WEEK_DATA);

  const todayEntries = entries.filter(e => e.date === new Date().toDateString());

  const totals = todayEntries.reduce(
    (acc, e) => ({
      cal: acc.cal + e.cal,
      protein: acc.protein + e.protein,
      carbs: acc.carbs + e.carbs,
      fat: acc.fat + e.fat,
    }),
    { cal: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const addEntry = useCallback((entry) => {
    const now = new Date();
    const hour = now.getHours();
    const meal = hour < 10 ? 'Breakfast' : hour < 14 ? 'Lunch' : hour < 17 ? 'Snack' : 'Dinner';
    const emojis = ['🥗','🍳','🥑','🍚','🥩','🫐','🍌','🥦','🧆','🥞','🍜','🥐'];
    const emoji = emojis[Math.floor(Math.random() * emojis.length)];
    setEntries(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        name: entry.name,
        meal,
        cal: Math.round(entry.calories),
        protein: Math.round(entry.protein_g),
        carbs: Math.round(entry.carbs_g),
        fat: Math.round(entry.fat_g),
        emoji,
        date: now.toDateString(),
      },
    ]);
  }, []);

  const removeEntry = useCallback((id) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  }, []);

  return (
    <AppContext.Provider value={{ entries, todayEntries, totals, goals: GOALS, streak, weekData, addEntry, removeEntry }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
