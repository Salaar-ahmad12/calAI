import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { Colors } from '../utils/theme';

export default function MacroRing({ size = 80, strokeWidth = 8, color, current, goal, label, unit = 'g' }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.min(current / goal, 1);
  const offset = circumference * (1 - pct);

  return (
    <View style={styles.wrap}>
      <Svg width={size} height={size} style={styles.svg}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={Colors.bg3}
          strokeWidth={strokeWidth}
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          rotation="-90"
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
      <View style={styles.center}>
        <Text style={[styles.val, { color }]}>{Math.round(current)}</Text>
        <Text style={styles.unit}>{unit}</Text>
      </View>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.goal}>{Math.round(current)} / {goal}{unit}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 6 },
  svg: {},
  center: {
    position: 'absolute',
    top: 0,
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  val: { fontSize: 18, fontWeight: '700', lineHeight: 20 },
  unit: { fontSize: 10, color: Colors.text3 },
  label: { fontSize: 12, color: Colors.text2, fontWeight: '500' },
  goal: { fontSize: 10, color: Colors.text3 },
});
