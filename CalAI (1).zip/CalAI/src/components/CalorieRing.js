import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle, Text as SvgText } from 'react-native-svg';
import { Colors } from '../utils/theme';

export default function CalorieRing({ consumed, goal, size = 140 }) {
  const strokeWidth = 13;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.min(consumed / goal, 1);
  const offset = circumference * (1 - pct);
  const remaining = Math.max(goal - consumed, 0);

  return (
    <View style={styles.wrap}>
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke={Colors.bg3} strokeWidth={strokeWidth}
        />
        <Circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke={Colors.accent} strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          rotation="-90"
          origin={`${size / 2}, ${size / 2}`}
        />
        <SvgText
          x={size / 2} y={size / 2 - 8}
          textAnchor="middle"
          fill={Colors.text}
          fontSize="24"
          fontWeight="700"
        >
          {consumed.toLocaleString()}
        </SvgText>
        <SvgText
          x={size / 2} y={size / 2 + 12}
          textAnchor="middle"
          fill={Colors.text2}
          fontSize="11"
        >
          consumed
        </SvgText>
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
});
