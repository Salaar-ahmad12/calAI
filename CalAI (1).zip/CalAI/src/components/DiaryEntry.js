import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Colors } from '../utils/theme';

export default function DiaryEntry({ entry, onDelete }) {
  const handleLongPress = () => {
    Alert.alert('Remove Entry', `Remove "${entry.name}" from your diary?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => onDelete(entry.id) },
    ]);
  };

  return (
    <TouchableOpacity style={styles.row} onLongPress={handleLongPress} activeOpacity={0.7}>
      <View style={styles.icon}>
        <Text style={styles.emoji}>{entry.emoji}</Text>
      </View>
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={1}>{entry.name}</Text>
        <Text style={styles.sub}>{entry.protein}g P · {entry.carbs}g C · {entry.fat}g F</Text>
      </View>
      <Text style={styles.cal}>{entry.cal}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.border,
    gap: 12,
  },
  icon: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: Colors.bg3,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emoji: { fontSize: 20 },
  info: { flex: 1 },
  name: { fontSize: 14, fontWeight: '500', color: Colors.text, marginBottom: 2 },
  sub: { fontSize: 12, color: Colors.text2 },
  cal: { fontSize: 15, fontWeight: '600', color: Colors.accent },
});
