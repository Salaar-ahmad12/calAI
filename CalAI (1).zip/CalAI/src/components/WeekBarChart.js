import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../utils/theme';

export default function WeekBarChart({ data, height = 110 }) {
  const maxCal = 2500;

  return (
    <View>
      <View style={[styles.chart, { height }]}>
        {data.map((d, i) => {
          const barH = d.cal ? Math.round((d.cal / maxCal) * (height - 24)) : 4;
          const color = !d.cal ? Colors.bg3 : d.cal > d.goal ? Colors.orange : Colors.accent;
          return (
            <View key={i} style={styles.barWrap}>
              <Text style={styles.barVal}>{d.cal && d.cal > 1900 ? d.cal : ''}</Text>
              <View style={[styles.bar, { height: barH, backgroundColor: color }]} />
              <Text style={styles.dayLabel}>{d.day}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 6,
    paddingBottom: 8,
  },
  barWrap: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  bar: {
    width: '100%',
    borderRadius: 6,
    minHeight: 4,
  },
  barVal: {
    fontSize: 9,
    color: Colors.text2,
    fontWeight: '500',
  },
  dayLabel: {
    fontSize: 10,
    color: Colors.text3,
  },
});
