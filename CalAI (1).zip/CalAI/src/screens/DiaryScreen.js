import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '../utils/theme';
import { useApp } from '../context/AppContext';
import MacroRing from '../components/MacroRing';
import DiaryEntry from '../components/DiaryEntry';

const MEAL_ORDER = ['Breakfast', 'Lunch', 'Snack', 'Dinner'];

export default function DiaryScreen({ navigation }) {
  const { todayEntries, totals, goals, removeEntry } = useApp();

  const grouped = MEAL_ORDER.reduce((acc, meal) => {
    const items = todayEntries.filter(e => e.meal === meal);
    if (items.length) acc[meal] = items;
    return acc;
  }, {});

  const dateStr = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{dateStr}</Text>
            <Text style={styles.title}>Food Diary</Text>
          </View>
          <View style={styles.totalBadge}>
            <Text style={styles.totalText}>{totals.cal} cal</Text>
          </View>
        </View>

        {/* Macro rings */}
        <View style={styles.section}>
          <View style={styles.card}>
            <View style={styles.ringsRow}>
              <MacroRing size={80} strokeWidth={7} color={Colors.protein} current={totals.protein} goal={goals.protein} label="Protein" />
              <MacroRing size={80} strokeWidth={7} color={Colors.carbs} current={totals.carbs} goal={goals.carbs} label="Carbs" />
              <MacroRing size={80} strokeWidth={7} color={Colors.fat} current={totals.fat} goal={goals.fat} label="Fat" />
            </View>
          </View>
        </View>

        {/* Entries by meal */}
        {Object.entries(grouped).map(([meal, items]) => {
          const mealTotal = items.reduce((s, e) => s + e.cal, 0);
          return (
            <View key={meal}>
              <View style={styles.mealHeader}>
                <Text style={styles.mealTitle}>{meal}</Text>
                <Text style={styles.mealCal}>{mealTotal} cal</Text>
              </View>
              <View style={[styles.section, { paddingTop: 0 }]}>
                <View style={styles.card}>
                  {items.map(e => (
                    <DiaryEntry key={e.id} entry={e} onDelete={removeEntry} />
                  ))}
                </View>
              </View>
            </View>
          );
        })}

        {todayEntries.length === 0 && (
          <View style={styles.emptyWrap}>
            <Text style={styles.emptyEmoji}>🍽</Text>
            <Text style={styles.emptyTitle}>Nothing logged yet</Text>
            <Text style={styles.emptySub}>Snap a photo of your food to get started</Text>
          </View>
        )}

        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('Scan')} activeOpacity={0.85}>
          <Text style={styles.addBtnText}>📷 Scan New Food</Text>
        </TouchableOpacity>
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8 },
  greeting: { fontSize: 13, color: Colors.text2, marginBottom: 2 },
  title: { fontSize: 24, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  totalBadge: { backgroundColor: 'rgba(168,255,62,0.1)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 8 },
  totalText: { fontSize: 14, color: Colors.accent, fontWeight: '700' },
  section: { paddingHorizontal: 20, marginBottom: 4, paddingTop: 0 },
  card: { backgroundColor: Colors.bg2, borderRadius: 20, padding: 16, borderWidth: 0.5, borderColor: Colors.border },
  ringsRow: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 8 },
  mealHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 10, marginBottom: 0 },
  mealTitle: { fontSize: 12, color: Colors.text3, letterSpacing: 0.8, textTransform: 'uppercase', fontWeight: '500' },
  mealCal: { fontSize: 12, color: Colors.accent, fontWeight: '600' },
  emptyWrap: { alignItems: 'center', paddingVertical: 60, gap: 8 },
  emptyEmoji: { fontSize: 48, marginBottom: 8 },
  emptyTitle: { fontSize: 18, fontWeight: '600', color: Colors.text },
  emptySub: { fontSize: 14, color: Colors.text2 },
  addBtn: { marginHorizontal: 20, marginTop: 16, backgroundColor: Colors.accent, borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  addBtnText: { fontSize: 15, fontWeight: '700', color: '#000' },
});
