import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '../utils/theme';
import { useApp } from '../context/AppContext';
import WeekBarChart from '../components/WeekBarChart';

const STAT_CARDS = [
  { label: 'AVG CALORIES', val: '1,720', sub: '280 under goal' },
  { label: 'STREAK', val: '🔥 7', sub: 'days logged' },
  { label: 'AVG PROTEIN', val: '112g', sub: 'of 160g goal', color: Colors.protein },
  { label: 'DAYS ON GOAL', val: '5/7', sub: 'Great week!', subColor: Colors.accent },
];

export default function ProgressScreen() {
  const { weekData, streak, goals, totals } = useApp();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Your journey</Text>
            <Text style={styles.title}>Progress</Text>
          </View>
        </View>

        {/* Weekly chart */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Weekly Calories</Text>
          <View style={styles.card}>
            <WeekBarChart data={weekData} height={130} />
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.accent }]} />
                <Text style={styles.legendText}>On target</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.orange }]} />
                <Text style={styles.legendText}>Over goal</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Stats grid */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Stats This Week</Text>
          <View style={styles.statsGrid}>
            {STAT_CARDS.map((s, i) => (
              <View key={i} style={styles.statCard}>
                <Text style={styles.statLabel}>{s.label}</Text>
                <Text style={[styles.statVal, s.color ? { color: s.color } : {}]}>{s.val}</Text>
                <Text style={[styles.statSub, s.subColor ? { color: s.subColor } : {}]}>{s.sub}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Goals */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Daily Goals</Text>
          <View style={styles.card}>
            {[
              { name: 'Calories', sub: 'Daily target', val: `${goals.calories}` },
              { name: 'Protein', sub: 'Build & preserve muscle', val: `${goals.protein}g` },
              { name: 'Carbohydrates', sub: 'Energy for workouts', val: `${goals.carbs}g` },
              { name: 'Fat', sub: 'Hormone & cell health', val: `${goals.fat}g` },
            ].map((g, i, arr) => (
              <View key={g.name} style={[styles.goalRow, i === arr.length - 1 && { borderBottomWidth: 0 }]}>
                <View style={styles.goalInfo}>
                  <Text style={styles.goalName}>{g.name}</Text>
                  <Text style={styles.goalSub}>{g.sub}</Text>
                </View>
                <View style={styles.goalBadge}>
                  <Text style={styles.goalBadgeText}>{g.val}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Macro breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Today's Macros</Text>
          <View style={styles.card}>
            {[
              { label: 'Protein', current: totals.protein, goal: goals.protein, color: Colors.protein },
              { label: 'Carbs', current: totals.carbs, goal: goals.carbs, color: Colors.carbs },
              { label: 'Fat', current: totals.fat, goal: goals.fat, color: Colors.fat },
            ].map(m => {
              const pct = Math.min((m.current / m.goal) * 100, 100);
              return (
                <View key={m.label} style={styles.macroProgressRow}>
                  <View style={styles.macroProgressHeader}>
                    <Text style={styles.macroProgressLabel}>{m.label}</Text>
                    <Text style={[styles.macroProgressVal, { color: m.color }]}>{m.current}g / {m.goal}g</Text>
                  </View>
                  <View style={styles.progressBg}>
                    <View style={[styles.progressFill, { width: `${pct}%`, backgroundColor: m.color }]} />
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8 },
  greeting: { fontSize: 13, color: Colors.text2, marginBottom: 2 },
  title: { fontSize: 24, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  section: { paddingHorizontal: 20, marginBottom: 20 },
  sectionLabel: { fontSize: 11, color: Colors.text3, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 10, fontWeight: '500' },
  card: { backgroundColor: Colors.bg2, borderRadius: 20, padding: 16, borderWidth: 0.5, borderColor: Colors.border },
  legendRow: { flexDirection: 'row', gap: 16, marginTop: 12 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 2 },
  legendText: { fontSize: 12, color: Colors.text2 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard: { backgroundColor: Colors.bg2, borderRadius: 16, padding: 16, borderWidth: 0.5, borderColor: Colors.border, width: '47.5%' },
  statLabel: { fontSize: 10, color: Colors.text3, letterSpacing: 0.8, marginBottom: 6 },
  statVal: { fontSize: 22, fontWeight: '700', color: Colors.text, marginBottom: 2 },
  statSub: { fontSize: 12, color: Colors.text2 },
  goalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  goalInfo: { flex: 1 },
  goalName: { fontSize: 14, fontWeight: '500', color: Colors.text },
  goalSub: { fontSize: 12, color: Colors.text2, marginTop: 2 },
  goalBadge: { backgroundColor: 'rgba(168,255,62,0.12)', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  goalBadgeText: { fontSize: 13, fontWeight: '700', color: Colors.accent },
  macroProgressRow: { marginBottom: 16 },
  macroProgressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  macroProgressLabel: { fontSize: 13, fontWeight: '500', color: Colors.text },
  macroProgressVal: { fontSize: 13, fontWeight: '600' },
  progressBg: { height: 6, backgroundColor: Colors.bg3, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
});
