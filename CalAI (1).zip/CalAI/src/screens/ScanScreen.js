import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Image, ActivityIndicator, Alert, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { Colors } from '../utils/theme';
import { analyzeFoodImage } from '../utils/api';
import { useApp } from '../context/AppContext';

const QUICK_ITEMS = [
  { label: '🍌 Banana', cal: 89, protein: 1, carbs_g: 23, fat_g: 0 },
  { label: '☕ Latte', cal: 190, protein: 7, carbs_g: 24, fat_g: 7 },
  { label: '🍎 Apple', cal: 95, protein: 0, carbs_g: 25, fat_g: 0 },
  { label: '🥜 PB Spoon', cal: 95, protein: 4, carbs_g: 3, fat_g: 8 },
  { label: '💧 Water', cal: 0, protein: 0, carbs_g: 0, fat_g: 0 },
  { label: '🥛 Milk (1 cup)', cal: 150, protein: 8, carbs_g: 12, fat_g: 8 },
];

const LOAD_MSGS = [
  'Analyzing your meal with AI...',
  'Detecting ingredients...',
  'Calculating macros...',
  'Almost done...',
];

export default function ScanScreen() {
  const { addEntry } = useApp();
  const [imageUri, setImageUri] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadMsgIdx, setLoadMsgIdx] = useState(0);
  const [result, setResult] = useState(null);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access to analyze food.');
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      base64: false,
    });
    if (!res.canceled && res.assets[0]) {
      handleImage(res.assets[0].uri);
    }
  };

  const openCamera = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow camera access to photograph meals.');
      return;
    }
    const res = await ImagePicker.launchCameraAsync({
      quality: 0.7,
      base64: false,
    });
    if (!res.canceled && res.assets[0]) {
      handleImage(res.assets[0].uri);
    }
  };

  const handleImage = async (uri) => {
    setImageUri(uri);
    setResult(null);
    setLoading(true);
    setLoadMsgIdx(0);

    const interval = setInterval(() => {
      setLoadMsgIdx(i => (i + 1) % LOAD_MSGS.length);
    }, 1300);

    try {
      const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
      const ext = uri.split('.').pop()?.toLowerCase();
      const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
      const data = await analyzeFoodImage(base64, mime);
      setResult(data);
    } catch (err) {
      Alert.alert('Analysis failed', 'Could not analyze this image. Please try a clearer photo of your food.');
      setImageUri(null);
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  const handleAdd = () => {
    if (!result) return;
    addEntry(result);
    setResult(null);
    setImageUri(null);
    Alert.alert('Added!', `${result.name} has been added to your diary.`);
  };

  const handleReset = () => {
    setResult(null);
    setImageUri(null);
  };

  const quickAdd = (item) => {
    addEntry({
      name: item.label.replace(/^\S+\s/, ''),
      calories: item.cal,
      protein_g: item.protein,
      carbs_g: item.carbs_g,
      fat_g: item.fat_g,
    });
    Alert.alert('Added!', `${item.label} added to your diary.`);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>AI-powered</Text>
            <Text style={styles.title}>Snap & Track</Text>
          </View>
          <TouchableOpacity style={styles.uploadBtn} onPress={pickImage}>
            <Text style={styles.uploadBtnText}>⬆ Upload</Text>
          </TouchableOpacity>
        </View>

        {/* Camera / preview area */}
        {!imageUri ? (
          <View style={styles.section}>
            <TouchableOpacity style={styles.cameraArea} onPress={openCamera} activeOpacity={0.85}>
              <View style={styles.cameraInner}>
                <View style={styles.cameraIcon}>
                  <Text style={{ fontSize: 32 }}>📷</Text>
                </View>
                <Text style={styles.cameraText}>Photograph your meal</Text>
                <Text style={styles.cameraSub}>AI analyzes calories & macros instantly</Text>
              </View>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.section}>
            <Image source={{ uri: imageUri }} style={styles.preview} />
          </View>
        )}

        {/* Loading */}
        {loading && (
          <View style={styles.loadingWrap}>
            <ActivityIndicator size="large" color={Colors.accent} />
            <Text style={styles.loadingText}>{LOAD_MSGS[loadMsgIdx]}</Text>
          </View>
        )}

        {/* Result */}
        {result && !loading && (
          <>
            <View style={styles.section}>
              <View style={styles.resultCard}>
                <View style={styles.resultHeader}>
                  <View style={styles.aiBadge}><Text style={styles.aiBadgeText}>AI ANALYSIS</Text></View>
                  <Text style={styles.foodName} numberOfLines={2}>{result.name}</Text>
                </View>
                <View style={styles.macrosRow}>
                  {[
                    { label: 'Calories', val: Math.round(result.calories), color: Colors.accent, unit: '' },
                    { label: 'Protein', val: Math.round(result.protein_g), color: Colors.protein, unit: 'g' },
                    { label: 'Carbs', val: Math.round(result.carbs_g), color: Colors.carbs, unit: 'g' },
                    { label: 'Fat', val: Math.round(result.fat_g), color: Colors.fat, unit: 'g' },
                  ].map(m => (
                    <View key={m.label} style={styles.macroCol}>
                      <Text style={[styles.macroVal, { color: m.color }]}>{m.val}{m.unit}</Text>
                      <Text style={styles.macroLabel}>{m.label}</Text>
                    </View>
                  ))}
                </View>
                <View style={styles.notesBox}>
                  <Text style={styles.notesText}>
                    {result.serving ? `${result.serving} · ` : ''}{result.notes}
                  </Text>
                </View>
              </View>
            </View>
            <TouchableOpacity style={styles.addBtn} onPress={handleAdd} activeOpacity={0.85}>
              <Text style={styles.addBtnText}>+ Add to Diary</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryBtn} onPress={handleReset} activeOpacity={0.85}>
              <Text style={styles.secondaryBtnText}>Scan Another</Text>
            </TouchableOpacity>
          </>
        )}

        {/* Quick add */}
        {!loading && !result && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Quick Add</Text>
            <View style={styles.pillsWrap}>
              {QUICK_ITEMS.map(item => (
                <TouchableOpacity key={item.label} style={styles.pill} onPress={() => quickAdd(item)} activeOpacity={0.7}>
                  <Text style={styles.pillText}>{item.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8 },
  greeting: { fontSize: 13, color: Colors.text2, marginBottom: 2 },
  title: { fontSize: 24, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  uploadBtn: { backgroundColor: 'rgba(168,255,62,0.1)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10 },
  uploadBtnText: { fontSize: 13, color: Colors.accent, fontWeight: '600' },
  section: { paddingHorizontal: 20, marginBottom: 20 },
  cameraArea: { borderRadius: 24, overflow: 'hidden' },
  cameraInner: {
    height: 220, borderRadius: 24, borderWidth: 1.5,
    borderColor: 'rgba(168,255,62,0.3)', borderStyle: 'dashed',
    backgroundColor: 'rgba(168,255,62,0.03)',
    alignItems: 'center', justifyContent: 'center', gap: 12,
  },
  cameraIcon: { width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(168,255,62,0.12)', alignItems: 'center', justifyContent: 'center' },
  cameraText: { fontSize: 16, fontWeight: '600', color: Colors.text },
  cameraSub: { fontSize: 13, color: Colors.text2 },
  preview: { width: '100%', height: 220, borderRadius: 24 },
  loadingWrap: { alignItems: 'center', paddingVertical: 32, gap: 16 },
  loadingText: { fontSize: 14, color: Colors.text2, textAlign: 'center' },
  resultCard: { backgroundColor: Colors.bg2, borderRadius: 24, overflow: 'hidden', borderWidth: 0.5, borderColor: Colors.border },
  resultHeader: { padding: 16, backgroundColor: 'rgba(168,255,62,0.08)', borderBottomWidth: 0.5, borderBottomColor: 'rgba(168,255,62,0.15)', gap: 6 },
  aiBadge: { backgroundColor: Colors.accent, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' },
  aiBadgeText: { fontSize: 10, fontWeight: '700', color: '#000', letterSpacing: 0.5 },
  foodName: { fontSize: 18, fontWeight: '700', color: Colors.text },
  macrosRow: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 20, paddingHorizontal: 16 },
  macroCol: { alignItems: 'center', gap: 4 },
  macroVal: { fontSize: 22, fontWeight: '700' },
  macroLabel: { fontSize: 11, color: Colors.text2 },
  notesBox: { marginHorizontal: 16, marginBottom: 16, backgroundColor: Colors.bg3, borderRadius: 12, padding: 12 },
  notesText: { fontSize: 13, color: Colors.text2, lineHeight: 18 },
  addBtn: { marginHorizontal: 20, marginBottom: 10, backgroundColor: Colors.accent, borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  addBtnText: { fontSize: 16, fontWeight: '700', color: '#000' },
  secondaryBtn: { marginHorizontal: 20, marginBottom: 20, backgroundColor: Colors.bg3, borderRadius: 16, paddingVertical: 16, alignItems: 'center', borderWidth: 0.5, borderColor: Colors.borderLight },
  secondaryBtnText: { fontSize: 15, fontWeight: '600', color: Colors.text },
  sectionLabel: { fontSize: 11, color: Colors.text3, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 10, fontWeight: '500' },
  pillsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pill: { backgroundColor: Colors.bg3, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 9, borderWidth: 0.5, borderColor: Colors.border },
  pillText: { fontSize: 13, color: Colors.text2 },
});
