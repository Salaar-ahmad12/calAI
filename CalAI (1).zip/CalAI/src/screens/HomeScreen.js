import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '../utils/theme';
import { useApp } from '../context/AppContext';
import CalorieRing from '../components/CalorieRing';
import MacroRing from '../components/MacroRing';
import WeekBarChart from '../components/WeekBarChart';
import DiaryEntry from '../components/DiaryEntry';

const DAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

export default function HomeScreen({ navigation }) {
  const { totals, goals, todayEntries, streak, weekData, removeEntry } = useApp();
  const remaining = Math.max(goals.calories - totals.cal, 0);
  const today = new Date().getDay();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good {new Date().getHours() < 12 ? 'morning' : 'evening'} 👋</Text>
            <Text style={styles.title}>Today's Summary</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>AK</Text>
          </View>
        </View>

        {/* Streak */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>🔥 {streak} Day Streak</Text>
          <View style={styles.streakRow}>
            {DAYS.map((d, i) => {
              const isToday = i === today;
              const done = i < today;
              return (
                <View key={i} style={[styles.streakDay, done && styles.streakDone, isToday && styles.streakToday]}>
                  <Text style={styles.streakD}>{d}</Text>
                  <Text style={styles.streakIcon}>{done || isToday ? '🔥' : '·'}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Calorie card */}
        <View style={styles.section}>
          <View style={styles.card}>
            <View style={styles.ringRow}>
              <CalorieRing consumed={totals.cal} goal={goals.calories} />
              <View style={styles.ringStats}>
                <View style={styles.ringStatsRow}>
                  <View>
                    <Text style={styles.statLabel}>Goal</Text>
                    <Text style={styles.statVal}>{goals.calories.toLocaleString()}</Text>
                  </View>
                  <View>
                    <Text style={styles.statLabel}>Burned</Text>
                    <Text style={styles.statVal}>340</Text>
                  </View>
                </View>
                <View style={styles.remainBox}>
                  <Text style={styles.remainLabel}>Remaining</Text>
                  <Text style={styles.remainVal}>{remaining.toLocaleString()}</Text>
                </View>
              </View>
            </View>
            {/* Macro bars */}
            <View style={styles.macroRow}>
              {[
                { label: 'Protein', val: totals.protein, goal: goals.protein, color: Colors.protein },
                { label: 'Carbs', val: totals.carbs, goal: goals.carbs, color: Colors.carbs },
                { label: 'Fat', val: totals.fat, goal: goals.fat, color: Colors.fat },
              ].map(m => (
                <View key={m.label} style={styles.macroItem}>
                  <Text style={[styles.macroVal, { color: m.color }]}>{m.val}g</Text>
                  <Text style={styles.macroName}>{m.label}</Text>
                  <View style={styles.macroBarBg}>
                    <View style={[styles.macroBarFill, { width: `${Math.min((m.val / m.goal) * 100, 100)}%`, backgroundColor: m.color }]} />
                  </View>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Today's log preview */}
        <View style={styles.section}>
          <View style={styles.rowBetween}>
            <Text style={styles.sectionLabel}>Today's Log</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Diary')}>
              <Text style={styles.seeAll}>See all →</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.card}>
            {todayEntries.slice(0, 3).map(e => (
              <DiaryEntry key={e.id} entry={e} onDelete={removeEntry} />
            ))}
            {todayEntries.length === 0 && (
              <Text style={styles.empty}>No entries yet — tap Scan to add food</Text>
            )}
          </View>
        </View>

        {/* Weekly chart */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>This Week</Text>
          <View style={styles.cardSm}>
            <WeekBarChart data={weekData} height={100} />
            <View style={styles.rowBetween}>
              <Text style={styles.chartMeta}>Avg: <Text style={{ color: Colors.text, fontWeight: '500' }}>1,720 cal</Text></Text>
              <Text style={styles.chartMeta}>Goal: <Text style={{ color: Colors.accent, fontWeight: '500' }}>2,000 cal</Text></Text>
            </View>
          </View>
        </View>

        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bg },
  scroll: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8 },
  greeting: { fontSize: 13, color: Colors.text2, marginBottom: 2 },
  title: { fontSize: 24, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  avatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.accent, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 14, fontWeight: '700', color: '#000' },
  section: { paddingHorizontal: 20, marginBottom: 20 },
  sectionLabel: { fontSize: 11, color: Colors.text3, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 10, fontWeight: '500' },
  card: { backgroundColor: Colors.bg2, borderRadius: 24, padding: 20, borderWidth: 0.5, borderColor: Colors.border },
  cardSm: { backgroundColor: Colors.bg2, borderRadius: 16, padding: 16, borderWidth: 0.5, borderColor: Colors.border },
  ringRow: { flexDirection: 'row', alignItems: 'center', gap: 24 },
  ringStats: { flex: 1 },
  ringStatsRow: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  statLabel: { fontSize: 11, color: Colors.text3, marginBottom: 2 },
  statVal: { fontSize: 18, fontWeight: '700', color: Colors.text },
  remainBox: { backgroundColor: 'rgba(168,255,62,0.1)', borderRadius: 12, padding: 10 },
  remainLabel: { fontSize: 12, color: Colors.text2 },
  remainVal: { fontSize: 22, fontWeight: '700', color: Colors.accent },
  macroRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
  macroItem: { flex: 1, backgroundColor: Colors.bg3, borderRadius: 12, padding: 12 },
  macroVal: { fontSize: 18, fontWeight: '700', marginBottom: 2 },
  macroName: { fontSize: 11, color: Colors.text2, marginBottom: 8 },
  macroBarBg: { height: 3, backgroundColor: Colors.bg4, borderRadius: 2, overflow: 'hidden' },
  macroBarFill: { height: '100%', borderRadius: 2 },
  streakRow: { flexDirection: 'row', gap: 8 },
  streakDay: { flex: 1, backgroundColor: Colors.bg3, borderRadius: 10, padding: 10, alignItems: 'center' },
  streakDone: { backgroundColor: 'rgba(168,255,62,0.15)', borderWidth: 0.5, borderColor: 'rgba(168,255,62,0.3)' },
  streakToday: { backgroundColor: 'rgba(168,255,62,0.25)', borderWidth: 0.5, borderColor: Colors.accent },
  streakD: { fontSize: 10, color: Colors.text3, marginBottom: 4 },
  streakIcon: { fontSize: 14 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  seeAll: { fontSize: 12, color: Colors.accent },
  empty: { fontSize: 13, color: Colors.text2, textAlign: 'center', paddingVertical: 16 },
  chartMeta: { fontSize: 12, color: Colors.text2 },
});
